var THREESESSIONS = THREESESSIONS || {};
//= require font-awesome
//= require three.min.js
//= require OrbitControls.js
//= require Projector.js
//= require TransformControls.js
//= require client
//= require select
//= require view
;
